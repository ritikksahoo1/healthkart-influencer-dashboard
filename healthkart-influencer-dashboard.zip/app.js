// HealthKart Influencer Marketing Dashboard JavaScript

class InfluencerDashboard {
    constructor() {
        this.currentSection = 'overview';
        this.filters = {
            platform: 'all',
            category: 'all',
            tier: 'all',
            search: ''
        };
        
        // Data from the provided JSON
        this.data = {
            kpis: {
                total_revenue: 1405046,
                total_orders: 1046,
                total_payouts: 234850,
                avg_roas: 9.41,
                avg_incremental_roas: 6.59,
                total_influencers: 50,
                total_posts: 200
            },
            platform_performance: [
                {source: "Instagram", traditional_roas: 8.97, incremental_roas: 6.28, revenue: 474991, orders: 349, engagement_rate: 12.93},
                {source: "TikTok", traditional_roas: 11.63, incremental_roas: 8.14, revenue: 382692, orders: 296, engagement_rate: 12.00},
                {source: "Twitter", traditional_roas: 9.46, incremental_roas: 6.63, revenue: 258641, orders: 197, engagement_rate: 12.00},
                {source: "YouTube", traditional_roas: 7.05, incremental_roas: 4.93, revenue: 288722, orders: 204, engagement_rate: 16.95}
            ],
            top_influencers: [
                {name: "Influencer_16", revenue: 68258, traditional_roas: 5.34, tier: "Mid", source: "YouTube", follower_count: 147867},
                {name: "Influencer_45", revenue: 67530, traditional_roas: 3.23, tier: "Mid", source: "Instagram", follower_count: 260178},
                {name: "Influencer_47", revenue: 59374, traditional_roas: 7.18, tier: "Micro", source: "Instagram", follower_count: 89432},
                {name: "Influencer_35", revenue: 54720, traditional_roas: 2.44, tier: "Macro", source: "TikTok", follower_count: 456789},
                {name: "Influencer_36", revenue: 54715, traditional_roas: 5.51, tier: "Mid", source: "Twitter", follower_count: 198765}
            ],
            tier_analysis: [
                {tier: "Micro", traditional_roas: 6.00, incremental_roas: 4.20, revenue: 160751, orders: 116, engagement_rate: 14.91, follower_count: 58806},
                {tier: "Mid", traditional_roas: 11.16, incremental_roas: 7.81, revenue: 737739, orders: 551, engagement_rate: 14.40, follower_count: 189800},
                {tier: "Macro", traditional_roas: 7.93, incremental_roas: 5.55, revenue: 506556, orders: 379, engagement_rate: 11.27, follower_count: 392609}
            ]
        };

        // Sample payout data
        this.payoutData = [
            {name: "Influencer_16", basis: "Per Post", rate: "₹15,000", total_payout: "₹45,000", status: "paid"},
            {name: "Influencer_45", basis: "Per Order", rate: "₹250", total_payout: "₹67,500", status: "pending"},
            {name: "Influencer_47", basis: "Per Post", rate: "₹8,000", total_payout: "₹24,000", status: "paid"},
            {name: "Influencer_35", basis: "Per Order", rate: "₹180", total_payout: "₹36,000", status: "processing"},
            {name: "Influencer_36", basis: "Per Post", rate: "₹12,000", total_payout: "₹36,000", status: "paid"},
            {name: "Influencer_22", basis: "Per Order", rate: "₹200", total_payout: "₹20,000", status: "pending"},
            {name: "Influencer_31", basis: "Per Post", rate: "₹6,000", total_payout: "₹18,000", status: "paid"},
            {name: "Influencer_28", basis: "Per Order", rate: "₹300", total_payout: "₹30,000", status: "processing"}
        ];

        this.init();
    }

    init() {
        this.setupEventListeners();
        this.populateData();
        // Delay chart setup to ensure DOM is ready
        setTimeout(() => {
            this.setupCharts();
        }, 100);
    }

    setupEventListeners() {
        // Navigation tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                const sectionId = e.target.dataset.section;
                this.switchSection(sectionId);
            });
        });

        // Filter controls
        const platformFilter = document.getElementById('platform-filter');
        if (platformFilter) {
            platformFilter.addEventListener('change', (e) => {
                this.filters.platform = e.target.value;
                this.applyFilters();
            });
        }

        const categoryFilter = document.getElementById('category-filter');
        if (categoryFilter) {
            categoryFilter.addEventListener('change', (e) => {
                this.filters.category = e.target.value;
                this.applyFilters();
            });
        }

        const tierFilter = document.getElementById('tier-filter');
        if (tierFilter) {
            tierFilter.addEventListener('change', (e) => {
                this.filters.tier = e.target.value;
                this.applyFilters();
            });
        }

        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filters.search = e.target.value.toLowerCase();
                this.applyFilters();
            });
        }

        const paymentFilter = document.getElementById('payment-status-filter');
        if (paymentFilter) {
            paymentFilter.addEventListener('change', (e) => {
                this.filterPayoutTable(e.target.value);
            });
        }

        // Reset filters
        const resetBtn = document.getElementById('reset-filters');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetFilters();
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }

        // Export functionality
        const exportBtn = document.getElementById('export-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportData();
            });
        }
    }

    switchSection(sectionId) {
        console.log('Switching to section:', sectionId);
        
        // Update navigation active state
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        const activeTab = document.querySelector(`[data-section="${sectionId}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // Update content sections - hide all first
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
            section.style.display = 'none';
        });
        
        // Show the selected section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            targetSection.style.display = 'block';
        }

        this.currentSection = sectionId;
        
        // Setup charts for the active section if needed
        if (sectionId === 'roas-analysis' || sectionId === 'influencer-insights') {
            setTimeout(() => {
                this.setupCharts();
            }, 100);
        }
    }

    populateData() {
        this.populatePlatformTable();
        this.populateTopInfluencersTable();
        this.populateTierAnalysis();
        this.populateTopPerformers();
        this.populatePayoutTable();
    }

    populatePlatformTable() {
        const tbody = document.querySelector('#platform-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        this.data.platform_performance.forEach(platform => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${platform.source}</td>
                <td>₹${platform.revenue.toLocaleString()}</td>
                <td>${platform.orders}</td>
                <td>${platform.traditional_roas.toFixed(2)}x</td>
                <td>${platform.engagement_rate.toFixed(1)}%</td>
            `;
            tbody.appendChild(row);
        });
    }

    populateTopInfluencersTable() {
        const tbody = document.querySelector('#top-influencers-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        let influencersToShow = this.data.top_influencers;
        
        // Apply search filter if active
        if (this.filters.search) {
            influencersToShow = this.data.top_influencers.filter(influencer => 
                influencer.name.toLowerCase().includes(this.filters.search) ||
                influencer.tier.toLowerCase().includes(this.filters.search) ||
                influencer.source.toLowerCase().includes(this.filters.search)
            );
        }

        influencersToShow.forEach(influencer => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${influencer.name}</td>
                <td>₹${influencer.revenue.toLocaleString()}</td>
                <td>${influencer.traditional_roas.toFixed(2)}x</td>
                <td><span class="status status--info">${influencer.tier}</span></td>
                <td>${influencer.source}</td>
            `;
            tbody.appendChild(row);
        });
    }

    populateTierAnalysis() {
        const container = document.getElementById('tier-analysis');
        if (!container) return;
        
        container.innerHTML = '';

        this.data.tier_analysis.forEach(tier => {
            const tierElement = document.createElement('div');
            tierElement.className = 'tier-item';
            tierElement.innerHTML = `
                <div class="tier-name">${tier.tier}</div>
                <div class="tier-stats">
                    <span class="tier-stat">ROAS: ${tier.traditional_roas.toFixed(2)}x</span>
                    <span class="tier-stat">Revenue: ₹${tier.revenue.toLocaleString()}</span>
                    <span class="tier-stat">Orders: ${tier.orders}</span>
                </div>
            `;
            container.appendChild(tierElement);
        });
    }

    populateTopPerformers() {
        const container = document.getElementById('top-performers');
        if (!container) return;
        
        container.innerHTML = '';

        this.data.top_influencers.slice(0, 3).forEach(performer => {
            const performerElement = document.createElement('div');
            performerElement.className = 'performer-item';
            performerElement.innerHTML = `
                <div class="performer-name">${performer.name}</div>
                <div class="performer-revenue">₹${performer.revenue.toLocaleString()}</div>
            `;
            container.appendChild(performerElement);
        });
    }

    populatePayoutTable() {
        const tbody = document.querySelector('#payout-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        this.payoutData.forEach(payout => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${payout.name}</td>
                <td>${payout.basis}</td>
                <td>${payout.rate}</td>
                <td>${payout.total_payout}</td>
                <td><span class="status-badge ${payout.status}">${payout.status}</span></td>
            `;
            tbody.appendChild(row);
        });
    }

    setupCharts() {
        this.setupPlatformChart();
        this.setupDemographicChart();
    }

    setupPlatformChart() {
        const ctx = document.getElementById('platform-chart');
        if (!ctx || !window.Chart) return;

        // Destroy existing chart if it exists
        if (ctx.chart) {
            ctx.chart.destroy();
        }

        ctx.chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.data.platform_performance.map(p => p.source),
                datasets: [{
                    label: 'Traditional ROAS',
                    data: this.data.platform_performance.map(p => p.traditional_roas),
                    backgroundColor: '#1FB8CD',
                    borderColor: '#1FB8CD',
                    borderWidth: 1
                }, {
                    label: 'Incremental ROAS',
                    data: this.data.platform_performance.map(p => p.incremental_roas),
                    backgroundColor: '#FFC185',
                    borderColor: '#FFC185',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'ROAS Value'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Platform'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                }
            }
        });
    }

    setupDemographicChart() {
        const ctx = document.getElementById('demographic-chart');
        if (!ctx || !window.Chart) return;

        // Destroy existing chart if it exists
        if (ctx.chart) {
            ctx.chart.destroy();
        }

        // Sample demographic data
        const demographicData = [
            { category: 'Fitness', count: 50 },
            { category: 'Health', count: 50 },
            { category: 'Lifestyle', count: 40 },
            { category: 'Wellness', count: 30 },
            { category: 'Sports', count: 35 }
        ];

        ctx.chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: demographicData.map(d => d.category),
                datasets: [{
                    data: demographicData.map(d => d.count),
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F', '#DB4545'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'right'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed || 0;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    applyFilters() {
        console.log('Applying filters:', this.filters);
        
        // Re-populate the top influencers table with filters applied
        this.populateTopInfluencersTable();
    }

    filterPayoutTable(status) {
        const tbody = document.querySelector('#payout-table tbody');
        if (!tbody) return;
        
        tbody.innerHTML = '';

        const filteredPayouts = status === 'all' 
            ? this.payoutData 
            : this.payoutData.filter(payout => payout.status === status);

        filteredPayouts.forEach(payout => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${payout.name}</td>
                <td>${payout.basis}</td>
                <td>${payout.rate}</td>
                <td>${payout.total_payout}</td>
                <td><span class="status-badge ${payout.status}">${payout.status}</span></td>
            `;
            tbody.appendChild(row);
        });
    }

    resetFilters() {
        this.filters = {
            platform: 'all',
            category: 'all',
            tier: 'all',
            search: ''
        };

        // Reset form controls
        const platformFilter = document.getElementById('platform-filter');
        if (platformFilter) platformFilter.value = 'all';
        
        const categoryFilter = document.getElementById('category-filter');
        if (categoryFilter) categoryFilter.value = 'all';
        
        const tierFilter = document.getElementById('tier-filter');
        if (tierFilter) tierFilter.value = 'all';
        
        const searchInput = document.getElementById('search-input');
        if (searchInput) searchInput.value = '';

        // Repopulate data
        this.populateData();
    }

    toggleTheme() {
        const body = document.body;
        const themeToggle = document.getElementById('theme-toggle');
        
        if (body.getAttribute('data-color-scheme') === 'dark') {
            body.setAttribute('data-color-scheme', 'light');
            if (themeToggle) themeToggle.textContent = '🌙';
        } else {
            body.setAttribute('data-color-scheme', 'dark');
            if (themeToggle) themeToggle.textContent = '☀️';
        }
    }

    exportData() {
        let csvContent = '';
        const currentData = this.getCurrentSectionData();
        
        if (currentData.length > 0) {
            // Create CSV headers
            const headers = Object.keys(currentData[0]);
            csvContent += headers.join(',') + '\n';
            
            // Add data rows
            currentData.forEach(row => {
                const values = headers.map(header => {
                    let value = row[header];
                    // Handle values that might contain commas
                    if (typeof value === 'string' && value.includes(',')) {
                        value = `"${value}"`;
                    }
                    return value;
                });
                csvContent += values.join(',') + '\n';
            });
            
            // Create and download file
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `healthkart_${this.currentSection}_${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    getCurrentSectionData() {
        switch (this.currentSection) {
            case 'overview':
                return this.data.platform_performance;
            case 'roas-analysis':
                return this.data.tier_analysis;
            case 'influencer-insights':
                return this.data.top_influencers;
            case 'payout-tracking':
                return this.payoutData;
            default:
                return [];
        }
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing dashboard...');
    new InfluencerDashboard();
});

// Handle responsive behavior
window.addEventListener('resize', () => {
    // Trigger chart resize if needed
    if (window.Chart) {
        Object.values(Chart.instances || {}).forEach(chart => {
            if (chart && typeof chart.resize === 'function') {
                chart.resize();
            }
        });
    }
});